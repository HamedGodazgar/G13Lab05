library(testthat)
library(PackG13Lab05)

test_check("PackG13Lab05")
