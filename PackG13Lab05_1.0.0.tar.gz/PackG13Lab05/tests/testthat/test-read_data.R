
#context('read_data')

test_that('Downloading a big query',{
  expect_error(file_size(url))
})

